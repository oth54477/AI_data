import DB_data_for_AI as DB

data = DB.DB_data('12:0')
print(data)